document.getElementById("viewAnalytics").addEventListener("click", () => {
  window.open("http://localhost:3000/analytics-dashboard", "_blank");
});
